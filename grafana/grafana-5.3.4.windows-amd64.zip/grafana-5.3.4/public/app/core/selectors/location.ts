export const getRouteParamsId = state => state.routeParams.id;

export const getRouteParamsPage = state => state.routeParams.page;
