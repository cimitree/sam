import { updateLocation } from './location';
import { updateNavIndex, UpdateNavIndexAction } from './navModel';

export { updateLocation, updateNavIndex, UpdateNavIndexAction };
